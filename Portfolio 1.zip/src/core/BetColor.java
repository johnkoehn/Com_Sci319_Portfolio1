package core;

public enum BetColor
{
	RED,
	BLACK,
	GREEN,
	NONE
}
